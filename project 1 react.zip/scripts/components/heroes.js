import React from 'react';

class Heroes extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }


    render() {
        return (
            <div className="container">
                <div className="row">
                    {this.props.heroes.map((hero, index) => {
                            return (
                                <div className="col-4 heroDiv" id={hero.name} key={index}>
                                    <p className="nameCenter marginTop"> {hero.name} </p>
                                    <button onClick={() => this.props.removeHero(index)}><img className="imageCenter" id={hero.health} src={hero.button} /></button>
                                    <p className="marginTop"> Health: {hero.health} </p>
                                    <p> Mana: {hero.mana} </p>
                                    <p> Gold: {hero.gold} </p>
                                    <img className="abilities" src={hero.abilityOne.image} />
                                    <img className="abilities" src={hero.abilityTwo.image} />
                                    <img className="abilities" src={hero.abilityThree.image} />
                                </div>
                            )
                        })}
                </div>
            </div>
        )
    }
}

export default Heroes;