import React from 'react';

class Store extends React.Component {
    constructor(props) {
        super(props);
        this.state = { 
         
         }
    }
    render() { 
        return ( 
            <div className="container">
                <div className="row">
                {this.props.store.map((store, index) => {
                        return (
                            <div className="col-6 storeDiv" key={index}>
                                <p className="nameCenter marginTop"> {store.name} </p>
                                <button><img className="monsterIcon" src={store.image} /></button>
                                <p className="storeCenter"> Gold: {store.cost} </p>
                            </div>
                        )
                    })}
                </div>
            </div>
         )
    }
}
 
export default Store;