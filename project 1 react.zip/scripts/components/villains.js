import React from 'react';

class Villains extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }


    render() {
        return (
            <div className="container">
                <div className="row">
                {this.props.villains.map((villains, index) => {
                        return (
                            <div className="col-4 villainDiv" key={index}>
                                <p className="nameCenter marginTop"> {villains.name} </p>
                                <button><img className="monsterIcon" src={villains.image} /></button>
                                <p className="marginTop"> Health: {villains.health} </p>
                                <p> Strength: {villains.strength} </p>
                                <p> Gold: {villains.gold} </p>
                            </div>
                        )
                    })}

                </div>
            </div>
        )
    }
}

export default Villains;