import React from 'react';
import Battle from './battle';
import Header from './header';
import Heroes from './heroes';
import Villains from './villains';
import Store from './store';
// import ChooseHero from './chooseHero';
// import ShowHero from './showHero';

import Warrior from './images/heroes/warrior.png';
import Empress from './images/heroes/empress.png';
import Rogue from './images/heroes/rogue.png';
import WarriorSword from './images/abilities/spiked-dagger.png';
import ArcaneSword from './images/abilities/arcane-strike.png';
import Ragnarok from './images/abilities/ragnarok.png';
import CrystalRain from './images/abilities/crystal-rain.png';
import Lightning from './images/abilities/lightning-strike.png';
import Fire from './images/abilities/for-blaze.png';
import RogueSword from './images/abilities/silver-dagger.png';
import CuttingEdge from './images/abilities/cutting-edge.png';
import BookOfSecrets from './images/abilities/book-of-secrets.png';

import Gargoyle from './images/monsters/gargoyle.png';
import Dragon from './images/monsters/ice-dragon.png';
import Grizzly from './images/monsters/infected-grizzly.png';

import Potion from './images/items/potion.png';
import Ether from './images/items/ether.png';

class Container extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentVillain: [],
            // chooseHero: -1,
            heroes: [
                {
                    // isHidden: true,
                    name: "Warrior",
                    button: Warrior,
                    health: 150,
                    mana: 50,
                    gold: 10,
                    abilityOne: {
                        image: WarriorSword,
                        damage: 15,
                    },
                    abilityTwo: {
                        image: ArcaneSword,
                        damage: 20,
                        mana: 10
                    },
                    abilityThree: {
                        image: Ragnarok,
                        damage: 30,
                        mana: 25
                    },
                },
                {
                    // isHidden: true,
                    name: "Empress",
                    button: Empress,
                    health: 135,
                    mana: 100,
                    gold: 10,
                    abilityOne: {
                        image: CrystalRain,
                        damage: 10,
                        mana: 10
                    },
                    abilityTwo: {
                        image: Lightning,
                        damage: 20,
                        mana: 15
                    },
                    abilityThree: {
                        image: Fire,
                        damage: 35,
                        mana: 25
                    },
                },
                {
                    // isHidden: true,
                    name: "Rogue",
                    button: Rogue,
                    health: 120,
                    mana: 70,
                    gold: 10,
                    abilityOne: {
                        image: RogueSword,
                        damage: 10,
                    },
                    abilityTwo: {
                        image: CuttingEdge,
                        damage: 15,
                        mana: 10
                    },
                    abilityThree: {
                        image: BookOfSecrets,
                        damage: 20,
                        heal: 20,
                        mana: 25
                    }
                }
            ],

            villains: [
                {
                    // isHidden: false,
                    name: "Gargoyle",
                    image: Gargoyle,
                    health: 40,
                    strength: 15,
                    gold: 30
                },
                {
                    // isHidden: false,
                    name: "Ice Dragon",
                    image: Dragon,
                    health: 120,
                    strength: 30,
                    gold: 60
                },
                {
                    // isHidden: false,
                    name: "Infected Grizzly",
                    image: Grizzly,
                    health: 80,
                    strength: 25,
                    gold: 50
                }
            ],

            store: [
                {
                    // isHidden: false,
                    name: "Potion",
                    image: Potion,
                    heal: 50,
                    cost: 30,
                },
                {
                    // isHidden: false,
                    name: "Ether",
                    image: Ether,
                    heal: 50,
                    cost: 20,
                }
            ]
        }
    }


    removeOneAndTwo() {
        let newArray = [...this.state.heroes];
        newArray.pop()
        newArray.pop()
        this.setState({
            heroes: newArray
        })
    }

    removeZeroAndTwo() {
        let newArray = [...this.state.heroes];
        newArray.pop()
        newArray.shift()
        this.setState({
            heroes: newArray
        })
    }

    removeZeroAndOne() {
        let newArray = [...this.state.heroes]
        newArray.shift();
        newArray.shift();
        this.setState({
            heroes: newArray
        })
    }


    removeHero(index) {
        // let newArray = [...this.state.heroes];
        if (index == 0) {
            this.removeOneAndTwo();
        }
        else if (index == 1) {
            this.removeZeroAndTwo();
        }
        else {
            this.removeZeroAndOne();
        }
        console.log(index)
    }

    toggleHidden() {
        this.setState({
            isHidden: !this.state.isHidden
        })
    }

    showMonster() {
        var index = 0
        let newArray = []
        if (this.state.villains[index].health < 1) {
            index++
        }
        newArray.push(this.state.villains[index])
        this.setState({
            isHidden: true,
            currentVillain: newArray
        })
    }

    heroAttackMonster() {
        this.state.villains[index].
    }
    

    render() {
        return (
            <div>
                <button onClick={this.showMonster.bind(this)}> Start </button>
                <button onClick={this.toggleHidden.bind(this)}> Next </button>
                <button onClick={this.toggleHidden.bind(this)}> Last </button>
                <Header />
                <Battle />
                <Heroes toggleHidden={this.toggleHidden.bind(this)}
                    removeHero={this.removeHero.bind(this)}
                    heroes={this.state.heroes} />
                {this.state.isHidden && <Villains
                    villains={this.state.currentVillain} />}
                {this.state.isHidden && <Store
                    store={this.state.store} />}
            </div>
        )
    }
}

export default Container;
