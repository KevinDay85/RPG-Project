import React, { Component } from 'react';
import React from 'react';

class ChooseHero extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>
                
            </div>
         )
    }
}
 
export default ChooseHero;