import React, { Component } from 'react';
import React from 'react';

class ShowHero extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>
                
            </div>
         )
    }
}
 
export default ShowHero;