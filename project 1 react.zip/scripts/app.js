import React from 'react';
import ReactDOM from 'react-dom';
import Container from './components/container'

import './styles/styles.css'

ReactDOM.render(<Container />, document.getElementById('example'));

